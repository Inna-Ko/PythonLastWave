
class Links:

    HOST = "http://qa-playground-social.com"

    LOGIN_PAGE = f"{HOST}/login"
    HOME_PAGE = f"{HOST}/home"
    CREATE_NEW_BUSINESS_PAGE = f"{HOST}/page/add"
    MESSAGE_PAGE = f"{HOST}/messages"